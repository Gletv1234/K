@echo off
setlocal
title Crear Gleyris Music Ultimate Setup

echo ==========================================
echo   GLE YRIS MUSIC ULTIMATE - BUILD SETUP
echo ==========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
  echo ERROR: Instala Python 3.11 o superior y vuelve a ejecutar.
  pause
  exit /b 1
)

echo [1/3] Instalando dependencias...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto error

echo [2/3] Creando la aplicacion Windows...
pyinstaller --noconfirm --clean --windowed --name "Gleyris Music Ultimate" --collect-all PySide6 main.py
if errorlevel 1 goto error

echo [3/3] Buscando Inno Setup...
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo.
  echo La aplicacion ya esta creada en dist.
  echo Para crear el instalador, instala Inno Setup 6 y ejecuta este archivo otra vez.
  echo Descarga: https://jrsoftware.org/isinfo.php
  pause
  exit /b 0
)

"%ISCC%" GleyrisMusicUltimate.iss
if errorlevel 1 goto error

echo.
echo LISTO. Busca el instalador en installer_output.
pause
exit /b 0

:error
echo.
echo ERROR durante la compilacion. Revisa los mensajes anteriores.
pause
exit /b 1
