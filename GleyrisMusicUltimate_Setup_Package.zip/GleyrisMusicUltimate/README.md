# Gleyris Music Ultimate

Starter desktop music player for Windows, built with Python and PySide6.

## Run
1. Install Python 3.11 or newer.
2. Open this folder in Terminal / Command Prompt.
3. Run:
   `python -m pip install -r requirements.txt`
4. Run:
   `python main.py`

## Build a Windows app
Double-click `build_windows.bat`. PyInstaller creates the application in `dist`.
For a distributable installer, package the generated app with an installer tool such as Inno Setup.

## Included in this starter
- Local audio library import (MP3, WAV, M4A, AAC, FLAC, OGG; playback depends on Windows codecs/Qt backend)
- Search library
- Play/pause, next/previous, seek and volume
- Shuffle and repeat
- Basic listening history
- Dark and light themes
- Local SQLite library database

## Planned next modules
Lyrics providers, metadata and cover-art lookup, real playlists, equalizer/DSP,
internet radio streams, mini-player, crossfade, richer visualizer and online services.
These require provider/API choices and additional implementation. No music catalog is bundled.
