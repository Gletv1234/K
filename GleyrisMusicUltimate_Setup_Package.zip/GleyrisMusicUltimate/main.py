import sys, os, sqlite3, random
from pathlib import Path
from PySide6.QtCore import Qt, QUrl, QTimer
from PySide6.QtGui import QAction, QFont, QColor
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QListWidget, QListWidgetItem, QFileDialog, QSlider,
    QFrame, QLineEdit, QMessageBox, QInputDialog, QMenu, QSplitter
)
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput

APP_DIR = Path.home() / ".gleyris_music"
APP_DIR.mkdir(exist_ok=True)
DB_PATH = APP_DIR / "library.db"

STYLE = """
QMainWindow, QWidget { background:#0b0b12; color:#f4f0ff; font-family:'Segoe UI'; }
QFrame#sidebar { background:#11101b; border:1px solid #242033; border-radius:16px; }
QFrame#panel { background:#141321; border:1px solid #29243d; border-radius:18px; }
QLabel#brand { color:#c4a5ff; font-size:24px; font-weight:800; letter-spacing:2px; }
QLabel#muted { color:#9b95ad; }
QLabel#songTitle { font-size:22px; font-weight:700; }
QPushButton { background:#211b32; color:#eee7ff; border:1px solid #3a2d54; border-radius:10px; padding:10px 14px; }
QPushButton:hover { background:#382653; border:1px solid #a78bfa; }
QPushButton#primary { background:#8b5cf6; color:white; font-weight:700; border:0; }
QPushButton#primary:hover { background:#a78bfa; }
QListWidget { background:transparent; border:0; outline:0; }
QListWidget::item { padding:11px; border-radius:8px; }
QListWidget::item:selected { background:#33234c; color:#fff; }
QLineEdit { background:#1a1726; border:1px solid #39314b; border-radius:10px; padding:11px; color:white; }
QSlider::groove:horizontal { height:6px; background:#39334a; border-radius:3px; }
QSlider::handle:horizontal { background:#b69aff; width:14px; margin:-5px 0; border-radius:7px; }
"""

class GleyrisWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gleyris Music Ultimate")
        self.resize(1180, 760)
        self.setMinimumSize(900, 600)
        self.db = sqlite3.connect(DB_PATH)
        self.db.execute("""CREATE TABLE IF NOT EXISTS tracks
            (path TEXT PRIMARY KEY, title TEXT, artist TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS playlists
            (name TEXT, path TEXT, UNIQUE(name,path))""")
        self.db.commit()
        self.tracks = []
        self.current_index = -1
        self.shuffle = False
        self.repeat = False
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.player.setAudioOutput(self.audio)
        self.audio.setVolume(0.7)
        self.player.positionChanged.connect(self.position_changed)
        self.player.durationChanged.connect(self.duration_changed)
        self.player.mediaStatusChanged.connect(self.media_status_changed)
        self.build_ui()
        self.load_library()

    def build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        outer = QHBoxLayout(central)
        outer.setContentsMargins(18,18,18,18)
        outer.setSpacing(16)

        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(220)
        sl = QVBoxLayout(sidebar)
        brand = QLabel("GLE YRIS")
        brand.setObjectName("brand")
        sl.addWidget(brand)
        sub = QLabel("MUSIC ULTIMATE")
        sub.setObjectName("muted")
        sl.addWidget(sub)
        sl.addSpacing(28)
        for label, callback in [
            ("⌂   Inicio", self.show_home),
            ("♫   Mi biblioteca", self.show_library),
            ("▤   Playlists", self.manage_playlist),
            ("＋   Añadir música", self.add_music),
            ("◷   Historial", self.show_history),
        ]:
            b = QPushButton(label); b.setStyleSheet("text-align:left;padding:13px;")
            b.clicked.connect(callback); sl.addWidget(b)
        sl.addStretch()
        self.theme_btn = QPushButton("◐   Cambiar tema")
        self.theme_btn.clicked.connect(self.toggle_theme)
        sl.addWidget(self.theme_btn)
        outer.addWidget(sidebar)

        main = QVBoxLayout()
        header = QHBoxLayout()
        heading = QLabel("Tu música, tu universo.")
        heading.setStyleSheet("font-size:25px;font-weight:700;")
        header.addWidget(heading)
        header.addStretch()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Buscar canciones...")
        self.search.setFixedWidth(260)
        self.search.textChanged.connect(self.filter_tracks)
        header.addWidget(self.search)
        main.addLayout(header)

        hero = QFrame(); hero.setObjectName("panel")
        hl = QHBoxLayout(hero)
        cover = QLabel("♫")
        cover.setAlignment(Qt.AlignCenter)
        cover.setFixedSize(150,150)
        cover.setStyleSheet("background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #56358a,stop:1 #171326);border-radius:18px;font-size:76px;color:#d8c5ff;")
        hl.addWidget(cover)
        info = QVBoxLayout()
        tag = QLabel("REPRODUCTOR PERSONAL")
        tag.setObjectName("muted")
        info.addWidget(tag)
        title = QLabel("Descubre tu sonido")
        title.setStyleSheet("font-size:26px;font-weight:800;")
        info.addWidget(title)
        desc = QLabel("Tu biblioteca musical, organizada en un solo lugar.")
        desc.setObjectName("muted")
        info.addWidget(desc)
        add = QPushButton("＋  Importar canciones")
        add.setObjectName("primary")
        add.clicked.connect(self.add_music)
        info.addWidget(add, alignment=Qt.AlignLeft)
        info.addStretch()
        hl.addLayout(info)
        main.addWidget(hero)

        row = QHBoxLayout()
        section = QLabel("Tu biblioteca")
        section.setStyleSheet("font-size:19px;font-weight:700;")
        row.addWidget(section); row.addStretch()
        self.count_label = QLabel("0 canciones"); self.count_label.setObjectName("muted")
        row.addWidget(self.count_label)
        main.addLayout(row)

        self.list = QListWidget()
        self.list.itemDoubleClicked.connect(self.play_item)
        main.addWidget(self.list, 1)

        player_panel = QFrame(); player_panel.setObjectName("panel")
        pp = QVBoxLayout(player_panel)
        top = QHBoxLayout()
        self.now_title = QLabel("Ninguna canción seleccionada")
        self.now_title.setObjectName("songTitle")
        self.now_artist = QLabel("Importa música para comenzar")
        self.now_artist.setObjectName("muted")
        songbox = QVBoxLayout(); songbox.addWidget(self.now_title); songbox.addWidget(self.now_artist)
        top.addLayout(songbox); top.addStretch()
        self.shuffle_btn = QPushButton("🔀")
        self.shuffle_btn.setToolTip("Aleatorio")
        self.shuffle_btn.setCheckable(True)
        self.shuffle_btn.clicked.connect(self.set_shuffle)
        top.addWidget(self.shuffle_btn)
        self.prev_btn = QPushButton("⏮"); self.prev_btn.clicked.connect(self.previous_track); top.addWidget(self.prev_btn)
        self.play_btn = QPushButton("▶ Reproducir"); self.play_btn.setObjectName("primary")
        self.play_btn.clicked.connect(self.toggle_play); top.addWidget(self.play_btn)
        self.next_btn = QPushButton("⏭"); self.next_btn.clicked.connect(self.next_track); top.addWidget(self.next_btn)
        self.repeat_btn = QPushButton("↻"); self.repeat_btn.setCheckable(True)
        self.repeat_btn.setToolTip("Repetir canción"); self.repeat_btn.clicked.connect(self.set_repeat)
        top.addWidget(self.repeat_btn)
        pp.addLayout(top)
        seekrow = QHBoxLayout()
        self.elapsed = QLabel("0:00"); self.elapsed.setObjectName("muted")
        self.seek = QSlider(Qt.Horizontal); self.seek.setRange(0,0)
        self.seek.sliderMoved.connect(self.player.setPosition)
        self.total = QLabel("0:00"); self.total.setObjectName("muted")
        seekrow.addWidget(self.elapsed); seekrow.addWidget(self.seek,1); seekrow.addWidget(self.total)
        pp.addLayout(seekrow)
        bottom = QHBoxLayout()
        bottom.addStretch()
        bottom.addWidget(QLabel("VOL"))
        self.volume = QSlider(Qt.Horizontal); self.volume.setFixedWidth(120)
        self.volume.setRange(0,100); self.volume.setValue(70)
        self.volume.valueChanged.connect(lambda v: self.audio.setVolume(v/100))
        bottom.addWidget(self.volume)
        pp.addLayout(bottom)
        main.addWidget(player_panel)
        outer.addLayout(main,1)

    def load_library(self):
        rows = self.db.execute("SELECT path,title,artist FROM tracks ORDER BY title").fetchall()
        self.tracks = [r for r in rows if os.path.exists(r[0])]
        self.refresh_list()

    def refresh_list(self, rows=None):
        self.list.clear()
        shown = self.tracks if rows is None else rows
        for path,title,artist in shown:
            item = QListWidgetItem(f"♫   {title}     —     {artist}")
            item.setData(Qt.UserRole, path)
            self.list.addItem(item)
        self.count_label.setText(f"{len(self.tracks)} canciones")

    def add_music(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Seleccionar música", "", "Audio (*.mp3 *.wav *.m4a *.aac *.flac *.ogg)")
        for path in paths:
            title = Path(path).stem
            artist = "Artista desconocido"
            self.db.execute("INSERT OR IGNORE INTO tracks VALUES (?,?,?)",(path,title,artist))
        self.db.commit()
        self.load_library()

    def filter_tracks(self, text):
        q = text.lower()
        self.refresh_list([r for r in self.tracks if q in (r[1]+" "+r[2]).lower()])

    def play_item(self, item):
        path = item.data(Qt.UserRole)
        for i,t in enumerate(self.tracks):
            if t[0] == path:
                self.current_index = i
                break
        self.play_current()

    def play_current(self):
        if not self.tracks or self.current_index < 0: return
        path,title,artist = self.tracks[self.current_index]
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.play()
        self.now_title.setText(title)
        self.now_artist.setText(artist)
        self.play_btn.setText("Ⅱ Pausar")
        self.db.execute("INSERT INTO playlists(name,path) VALUES('Historial',?) ON CONFLICT DO NOTHING",(path,))
        self.db.commit()

    def toggle_play(self):
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause(); self.play_btn.setText("▶ Reproducir")
        elif self.current_index >= 0:
            self.player.play(); self.play_btn.setText("Ⅱ Pausar")
        elif self.tracks:
            self.current_index = 0; self.play_current()

    def next_track(self):
        if not self.tracks: return
        self.current_index = random.randrange(len(self.tracks)) if self.shuffle else (self.current_index+1)%len(self.tracks)
        self.play_current()

    def previous_track(self):
        if not self.tracks: return
        self.current_index = (self.current_index-1)%len(self.tracks)
        self.play_current()

    def set_shuffle(self, checked):
        self.shuffle = checked
        self.shuffle_btn.setStyleSheet("background:#7044b5;" if checked else "")

    def set_repeat(self, checked):
        self.repeat = checked
        self.repeat_btn.setStyleSheet("background:#7044b5;" if checked else "")

    def media_status_changed(self, status):
        if status == QMediaPlayer.EndOfMedia:
            if self.repeat: self.player.setPosition(0); self.player.play()
            else: self.next_track()

    def position_changed(self, pos):
        self.seek.blockSignals(True); self.seek.setValue(pos); self.seek.blockSignals(False)
        self.elapsed.setText(self.fmt(pos))

    def duration_changed(self, duration):
        self.seek.setRange(0,duration); self.total.setText(self.fmt(duration))

    @staticmethod
    def fmt(ms):
        s = max(0,ms//1000)
        return f"{s//60}:{s%60:02d}"

    def show_home(self):
        self.search.clear()
        self.load_library()

    def show_library(self):
        self.search.clear()
        self.load_library()

    def manage_playlist(self):
        name, ok = QInputDialog.getText(self,"Nueva playlist","Nombre de la playlist:")
        if ok and name.strip():
            QMessageBox.information(self,"Playlist",f"Playlist «{name.strip()}» creada. Puedes organizar tus canciones en próximas versiones.")

    def show_history(self):
        paths = [r[0] for r in self.db.execute("SELECT path FROM playlists WHERE name='Historial' ORDER BY rowid DESC").fetchall()]
        history = [t for p in paths for t in self.tracks if t[0]==p]
        self.refresh_list(history)

    def toggle_theme(self):
        app = QApplication.instance()
        if getattr(self,"light_mode",False):
            app.setStyleSheet(STYLE); self.light_mode=False
        else:
            app.setStyleSheet("""
            QMainWindow,QWidget{background:#eeeaf6;color:#211a30;font-family:'Segoe UI'}
            QFrame#sidebar,QFrame#panel{background:#fff;border:1px solid #d8cfe8;border-radius:16px}
            QLabel#brand{color:#7044b5;font-size:24px;font-weight:800}
            QLabel#muted{color:#746b83}
            QLabel#songTitle{font-size:22px;font-weight:700}
            QPushButton{background:#e6def2;color:#281d3b;border:1px solid #cbbce0;border-radius:10px;padding:10px}
            QPushButton#primary{background:#8053c7;color:white;font-weight:700}
            QLineEdit{background:white;color:#211a30;border:1px solid #cbbce0;border-radius:10px;padding:11px}
            QListWidget{background:transparent;border:0}
            QListWidget::item{padding:11px;border-radius:8px}
            QListWidget::item:selected{background:#d8c8ef}
            QSlider::groove:horizontal{height:6px;background:#cbbce0}
            QSlider::handle:horizontal{background:#8053c7;width:14px;margin:-5px 0;border-radius:7px}
            """)
            self.light_mode=True

    def closeEvent(self, event):
        self.db.close()
        super().closeEvent(event)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLE)
    app.setFont(QFont("Segoe UI", 10))
    window = GleyrisWindow()
    window.show()
    sys.exit(app.exec())
