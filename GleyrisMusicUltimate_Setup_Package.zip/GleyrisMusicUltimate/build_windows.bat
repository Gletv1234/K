@echo off
title Build Gleyris Music Ultimate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt pyinstaller
pyinstaller --noconfirm --clean --windowed --name "Gleyris Music Ultimate" main.py
echo.
echo Build finished. Check the dist folder.
pause
