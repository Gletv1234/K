#define MyAppName "Gleyris Music Ultimate"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Gleyris"
#define MyAppExeName "Gleyris Music Ultimate.exe"

[Setup]
AppId={{A3B0A8F1-1E2C-4E51-9F36-6A8D7C20B9F1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Gleyris Music Ultimate
DefaultGroupName={#MyAppName}
OutputDir=installer_output
OutputBaseFilename=Gleyris-Music-Ultimate-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\{#MyAppExeName}
PrivilegesRequired=admin

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un acceso directo en el escritorio"; GroupDescription: "Accesos adicionales:"; Flags: unchecked

[Files]
Source: "dist\Gleyris Music Ultimate\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Gleyris Music Ultimate"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Gleyris Music Ultimate"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Abrir Gleyris Music Ultimate"; Flags: postinstall nowait skipifsilent
