# Gleyris Music Ultimate — Windows setup

Este paquete prepara la versión actual del reproductor y genera un instalador de Windows.

## Crear el instalador
1. En Windows, instala Python 3.11+.
2. Instala Inno Setup 6: https://jrsoftware.org/isinfo.php
3. Descomprime el proyecto.
4. Ejecuta `build_setup.bat`.
5. El instalador aparecerá en `installer_output/Gleyris-Music-Ultimate-Setup.exe`.

## Funciones disponibles en esta versión
- Importación y reproducción de archivos locales.
- Búsqueda en la biblioteca.
- Play/Pause, anterior/siguiente, barra de progreso y volumen.
- Aleatorio y repetición.
- Historial básico.
- Temas oscuro y claro.

## Importante
Este instalador empaqueta las funciones que ya están implementadas. No convierte automáticamente en funcionales las funciones anunciadas como futuras (letras sincronizadas, ecualizador DSP, radio online, portadas automáticas, mini reproductor, crossfade y playlists completas). Esas funciones requieren desarrollo adicional.
